const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Router = express.Router();
const multer = require('multer');
const User = mongoose.model("User")
const jwt = require('jsonwebtoken');
const roles = require("user-groups-roles");
const httpMsgs = require("http-msgs");

const checkAuth = require('../middlewares/check-auth');


const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'public/')
    },

    filename: function(req, file, cb){
        cb(null, file.originalname)
    }
});

const fileFilter = (req, file, cb) => {
    if(file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'image/jpg'){
        cb(null, true);
    }
    else{
        cb(null, false);
    }
    
    
};

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter

        });

        /*
    Roles declaratations
*/ 
// roles
roles.createNewRole("admin");
roles.createNewRole("user");

// privileges
roles.createNewPrivileges(["/edit-profile", "GET"], "edit profile", true);
roles.createNewPrivileges(["/edit-profile", "POST"], "inserts profile", false);

// admin all add, edit delete select
roles.addPrivilegeToRole("admin",["/edit-profile", "POST"],false);

// user insert, edit select
roles.addPrivilegeToRole("user",["/edit-profile", "POST"],true);



Router.post('/sign-up', upload.single('productImage'), async (req, res, next) => {

    console.log(req.body);
    User.find({email: req.body.email})
    .exec()
    .then(user => {
        if(user.length >=1){
            res.status(409).json({
                Message: "User already exists"
            })
        }
        else{

            bcrypt.hash(req.body.password, 10, (err, hash) => {

                if(err){
                    res.status(500).json({
                        Error: "Error whilst hasting"
                    });
                }
                else{
                    const user = new User({
                        _id: mongoose.Types.ObjectId(),
                        name: req.body.name,
                        email: req.body.email,
                        role: req.body.role,
                        password: hash,
                        profileImage: req.file.filename
                    });
        
                    user
                    .save()
                    .then( result => {
                        console.log(result);
                        res.status(200).json({
                            Message: "Saved User"
                        });
                    })
                    .catch(err => {
                        console.log(err);
                        res.status(500).json({
                            Error: err,
                            Message:"Not Saved"
                        })
                    });
                }
        
        
           });

        }
    })
    .catch();


});

Router.post('/login',(req, res, next) => {

    
    User.find({email: req.body.email})
    .exec()
    .then(user => {

        if(user.length < 1){

          return  res.status(401).json({
                "Auth": "Auth Failed"
            });
        }
        bcrypt.compare(req.body.password,user[0].password, (err, result)=>{
            if(err){

                return  res.status(401).json({
                    "Auth": "Auth Failed"
                });
            }
            if(result){
              const token =  jwt.sign({
                    email: user[0].email,
                    id: user[0]._id

                },
                process.env.JWT_KEY,
                {
                    expiresIn: '1h'
                }
                );
                return  res.status(200).json({
                    Auth: "Auth Successfull",
                    Token : token,
                    name: user[0].name,
                    id: user[0]._id,
                    image: user[0].profileImage
                });

            }
            return  res.status(401).json({
                "Auth": "Auth Successfull"
            });
        })
    })
    .catch(err => {

        return  res.status(401).json({
            "Auth": "not successfull"
        });

    });
});

//Edit/ Update/ View Api

Router.post('/edit-profile', checkAuth,  (req, res) => {

    User.findById({_id: req.body.UserID})
    .exec()
    .then(user => {
        var value = roles.getRoleRoutePrivilegeValue(user.role, "/edit-profile", "POST");
        if(value){
            console.log('USER =>  '+ user.name);
             res.render('edit-profile', {user: user});
        }
        else{
            // httpMsgs.send500(req, res, "not allowed");
            res.render('501', {user: user});
        }
            

    });
});

//Update USER API

Router.post('/update-profile', upload.single('productImage'), async (req, res, next) => {

   
    console.log("Updation api");
    console.log(req.body.UserID);
    User.findByIdAndUpdate(
        {_id: req.body.UserID},
        {
            name: req.body.name,
            profileImage: req.file.filename
        },
        )
        .then(function(){
        User.findOne({_id: req.body.UserID}).then(function(API){
            res.send(API);
        });
    });
    
     
});

//Detele user is pending


module.exports = Router;
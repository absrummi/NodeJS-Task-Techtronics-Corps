const express = require("express");
require('express-async-errors');
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const ejs = require('ejs');

//Middleware
app.use(bodyParser.json());  

//public static assets

app.use(express.static('./public'));
app.set('view engine', 'ejs');

//database connection
require("./mongo");


//Models
require("./model/User");


    
//Routes
app.get('/', (req, res) => {

    res.render('home');
});

app.use("/users", require("./routes/users"));

app.use((req, res, next) => {
    req.status = 404;
    const error = new Error('Page not found');
    next(error);
});


//production?

if(app.get("env") === "production"){
    app.use((error, req, res, next) => {

        res.status(req.status||501).send({
            messages: error.message
        });
    });
}

app.use((error, req, res, next) => {

    res.status(req.status||501).send({
        messages: error.message,
        stack: error.stack
    });
});

app.listen(3001, function () {
    console.log("Server is running on port 3001");
})

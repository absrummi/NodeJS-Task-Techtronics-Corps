$(document).ready(() => {

    $('#sign-up-btnn').on('click', function() {
        console.log('click up');
        $('#sign-in-close').click();
    });
    //Close button for sign in sign-in-close

    $('#sign-in-close').on('click', function() {
        console.log('click login');
    });

    //logout 
    $('#header-logout').on('click', function() {
        sessionStorage.clear('token');
        location.reload();
    });
 

        //aJax call for sign up api sign-in-act-btn
        $('#login-act-btn').on('click', () => {

            var email = $('#login-email').val();
            var pass = $('#login-password').val();
            
            
            
            var data = {};
            data.email = email;
            data.password = pass;
            $.ajax({
    
                type: 'POST',
                url: 'http://localhost:3001/users/login',
                data: JSON.stringify(data),
                contentType: 'application/json',
                success: (data) => {
                    sessionStorage.setItem('UserID', data.id);
                    sessionStorage.setItem('token', data.Token);
                    sessionStorage.setItem('name', data.name);
                    sessionStorage.setItem('userImage', data.image);
                    showUserHasBeenAuthenticated();
                    $('#sign-in-close').click();

                    location.reload();
                }
            });
        });
    //Edit/View profile of User
    $('#edit-user-profile').on('click', () => {
        console.log("User Profile clicked");
        var data = {};
        data.UserID = sessionStorage.getItem('UserID');

        $.ajax({
            
            type:     'POST',
            url:      'http://localhost:3001/users/edit-profile',
            headers:  {
                      authorization: "Bearer "+ sessionStorage.getItem('token')
                },
            data: JSON.stringify(data),
            contentType: 'application/json',

            success:   (data) =>{
                console.log("Succeed in editing api call ");
                console.log(sessionStorage.getItem('UserID'));
                $("#dynamic-body").append(data);
                $('#UserID').val(sessionStorage.getItem('UserID'));
                // $('#edit-user-profile').click();
            }

        });
    });

    // Script to open and close sidebar
    function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }
  
  // Modal Image Gallery
  function onClick(element) {
    document.getElementById("img01").src = element.src;
    document.getElementById("modal01").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
  }

  //this call is to make sure if user is logged in or not in? I yes login button shouldn't displayed. This will make sence I guess
  showUserHasBeenAuthenticated();
});

  
  //uploading images?

  function readURL(input) {
    if (input.files && input.files[0]) {
  
      var reader = new FileReader();
  
      reader.onload = function(e) {
        $('.image-upload-wrap').hide();
  
        $('.file-upload-image').attr('src', e.target.result);
        $('.file-upload-content').show();
  
        $('.image-title').html(input.files[0].name);
      };
  
      reader.readAsDataURL(input.files[0]);
  
    } else {
      removeUpload();
    }
  }
  
  function removeUpload() {
    $('.file-upload-input').replaceWith($('.file-upload-input').clone());
    $('.file-upload-content').hide();
    $('.image-upload-wrap').show();
  }
  $('.image-upload-wrap').bind('dragover', function () {
          $('.image-upload-wrap').addClass('image-dropping');
      });
      $('.image-upload-wrap').bind('dragleave', function () {
          $('.image-upload-wrap').removeClass('image-dropping');
  });
  

  function showUserHasBeenAuthenticated(){
      console.log("Tokn => "+sessionStorage.getItem('token'));
      
    //    sessionStorage.clear('token');
      if(sessionStorage.getItem('token') != null)
      {
        $('#header-login').hide();
        $('#header-logout').css('display', 'inline-block');
        $("#header-login-wrapper").prepend("<p style = 'display: inline-block; color:black' >Welcome "+sessionStorage.getItem('name')+"   </p>");
        $("#header-login-wrapper").prepend('<figure  class="author-figure mb-0 mr-3 d-inline-block"><img  src= "/'+ sessionStorage.getItem('userImage') +  '" style = " width: 30px;border-radius: 50%;" alt="Image" class="img-fluid"></figure>');
        $('#makeAPost >  #UserID').val(sessionStorage.getItem('UserID'));
        $('#edit-user-profile').css('display', 'inline-block');
        
        console.log("UserID => "+sessionStorage.getItem('UserID'));
        
      }
      else{

        

      }
      

  }

